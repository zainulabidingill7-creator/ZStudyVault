package com.zain.studymate

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity: Activity() {
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private val prefs by lazy { getSharedPreferences("study", MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) { super.onCreate(b); buildUI() }

    private fun buildUI() {
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(20,20,20,12)}
        val title=TextView(this).apply{text="📚 StudyMate"; textSize=28f; setTextColor(Color.DKGRAY)}
        root.addView(title, LinearLayout.LayoutParams(-1,60))
        search=EditText(this).apply{hint="Search tabs..."; setSingleLine(true)}
        root.addView(search, LinearLayout.LayoutParams(-1,60))
        val bar=LinearLayout(this)
        val add=Button(this).apply{text="＋ New Tab"; setOnClickListener{newTab()}}
        val backup=Button(this).apply{text="Backup"; setOnClickListener{backup()}}
        val restore=Button(this).apply{text="Restore"; setOnClickListener{restore()}}
        bar.addView(add, LinearLayout.LayoutParams(0,60,1f)); bar.addView(backup,LinearLayout.LayoutParams(0,60,1f)); bar.addView(restore,LinearLayout.LayoutParams(0,60,1f))
        root.addView(bar)
        val sv=ScrollView(this); list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        sv.addView(list); root.addView(sv,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
        search.addTextChangedListener(object: android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}; override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render(s.toString())}; override fun afterTextChanged(e:android.text.Editable?){} })
        render()
    }
    private fun data(): JSONArray = try{JSONArray(prefs.getString("tabs","[]"))}catch(e:Exception){JSONArray()}
    private fun save(a:JSONArray){prefs.edit().putString("tabs",a.toString()).apply()}
    private fun newTab(){
        val e=EditText(this); e.hint="Tab name"
        AlertDialog.Builder(this).setTitle("Create new tab").setView(e).setPositiveButton("Create"){_,_->if(e.text.toString().trim().isNotEmpty()){val a=data(); a.put(JSONObject().apply{put("name",e.text.toString().trim());put("notes",JSONArray())});save(a);render()}}.setNegativeButton("Cancel",null).show()
    }
    private fun render(q:String=""){
        list.removeAllViews(); val a=data()
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i); val name=o.optString("name")
            if(q.isNotBlank()&&!name.contains(q,true))continue
            val b=Button(this).apply{text="📁 $name"; textSize=18f; gravity=Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener{openTab(i)}; setOnLongClickListener{confirmDelete(i);true}}
            list.addView(b,LinearLayout.LayoutParams(-1,68).apply{setMargins(0,6,0,6)})
        }
    }
    private fun openTab(index:Int){
        val a=data(); val o=a.getJSONObject(index); val notes=o.optJSONArray("notes")?:JSONArray()
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,10)}
        val head=TextView(this).apply{text="📁 "+o.optString("name");textSize=25f}
        box.addView(head,LinearLayout.LayoutParams(-1,60))
        val add=Button(this).apply{text="＋ New Note";setOnClickListener{newNote(index)}}
        box.addView(add)
        val sv=ScrollView(this); val nl=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; sv.addView(nl); box.addView(sv,LinearLayout.LayoutParams(-1,0,1f))
        for(j in 0 until notes.length()){val n=notes.getJSONObject(j); val b=Button(this).apply{text="📝 "+n.optString("title");gravity=Gravity.START;setOnClickListener{editNote(index,j)}};nl.addView(b,LinearLayout.LayoutParams(-1,65))}
        val back=Button(this).apply{text="← Back";setOnClickListener{buildUI()}};box.addView(back)
        setContentView(box)
    }
    private fun newNote(i:Int)=editNote(i,-1)
    private fun editNote(i:Int,j:Int){
        val a=data(); val o=a.getJSONObject(i); val notes=o.optJSONArray("notes")?:JSONArray()
        val title=EditText(this).apply{hint="Note title";setSingleLine(true);if(j>=0)setText(notes.getJSONObject(j).optString("title"))}
        val body=EditText(this).apply{hint="Write your study note...";minLines=8;gravity=Gravity.TOP; if(j>=0)setText(notes.getJSONObject(j).optString("body"))}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};box.addView(title);box.addView(body)
        AlertDialog.Builder(this).setTitle(if(j<0)"New note" else "Edit note").setView(box).setPositiveButton("Save"){_,_->val n=JSONObject().apply{put("title",title.text.toString());put("body",body.text.toString())};if(j<0)notes.put(n)else notes.put(j,n);o.put("notes",notes);save(a);openTab(i)}.setNegativeButton("Cancel",null).show()
    }
    private fun confirmDelete(i:Int){AlertDialog.Builder(this).setTitle("Delete tab?").setMessage("This tab and its notes will be deleted.").setPositiveButton("Delete"){_,_->val a=data();val n=JSONArray();for(j in 0 until a.length())if(j!=i)n.put(a.get(j));save(n);render()}.setNegativeButton("Cancel",null).show()}
    private fun backup(){val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="application/json";putExtra(Intent.EXTRA_TITLE,"studymate-backup.json")};startActivityForResult(intent,10)}
    private fun restore(){val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/json";addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(intent,11)}
    override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d?.data==null)return;try{if(r==10){contentResolver.openOutputStream(d.data!!)!!.use{it.write(prefs.getString("tabs","[]")!!.toByteArray())}}else{contentResolver.openInputStream(d.data!!)!!.bufferedReader().use{save(JSONArray(it.readText()));render()}}}catch(e:Exception){Toast.makeText(this,"Backup file invalid",Toast.LENGTH_LONG).show()}}
}
